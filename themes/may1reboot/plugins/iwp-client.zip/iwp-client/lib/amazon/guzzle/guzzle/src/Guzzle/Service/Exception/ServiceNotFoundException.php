<?php

namespace Guzzle\Service\Exception;

class ServiceNotFoundException extends ServiceBuilderException {}
