<?php

namespace Guzzle\Common\Exception;

class BadMethodCallException extends \BadMethodCallException implements GuzzleException {}
